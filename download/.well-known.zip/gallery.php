<head>
    
    	<?php include 'include_File/head.php';?>
    	<style>
    	    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');

::selection{
  color: #fff;
  background: #007bff;
}

.wrapper{
  margin: 100px auto;
  max-width: 1100px;
}
.wrapper nav{
  display: flex;
  justify-content: center;
}
.wrapper .items{
  display: flex;
  max-width: 720px;
  width: 100%;
  justify-content: space-between;
}
.items span{
  padding: 12px;
  font-size: 18px;
  font-weight: 500;
  cursor: pointer;
  color: #007bff;
  border-radius: 50px;
  border: 2px solid #007bff;
  transition: all 0.3s ease;
}
.items span.active,
.items span:hover{
  color: #fff;
  background: #007bff;
}

.gallery{
  display: flex;
  flex-wrap: wrap;
  margin-top: 30px;
}
.gallery .image{
  width: calc(100% / 4);
  padding: 7px;
}
.gallery .image span{
  display: flex;
  width: 100%;
  overflow: hidden;
}
.gallery .image img{
  width: 100%;
  vertical-align: middle;
  transition: all 0.3s ease;
}
.gallery .image:hover img{
  transform: scale(1.1);
}
.gallery .image.hide{
  display: none;
}
.gallery .image.show{
  animation: animate 0.4s ease;
}
@keyframes animate {
  0%{
    transform: scale(0.5);
  }
  100%{
    transform: scale(1);
  }
}

.preview-box{
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%) scale(0.9);
  background: #fff;
  max-width: 700px;
  width: 100%;
  z-index: 5;
  opacity: 0;
  pointer-events: none;
  border-radius: 3px;
  padding: 0 5px 5px 5px;
  box-shadow: 0px 0px 15px rgba(0,0,0,0.2);
}
.preview-box.show{
  opacity: 1;
  pointer-events: auto;
  transform: translate(-50%, -50%) scale(1);
  transition: all 0.3s ease;
}
.preview-box .details{
  padding: 13px 15px 13px 10px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.details .title{
  display: flex;
  font-size: 18px;
  font-weight: 400;
}
.details .title p{
  font-weight: 500;
  margin-left: 5px;
}
.details .icon{
  color: #007bff;
  font-style: 22px;
  cursor: pointer;
}
.preview-box .image-box{
  width: 100%;
  display: flex;
}
.image-box img{
  width: 100%;
  border-radius: 0 0 3px 3px;
}
.shadow{
  position: fixed;
  left: 0;
  top: 0;
  height: 100%;
  width: 100%;
  z-index: 2;
  display: none;
  background: rgba(0,0,0,0.4);
}
.shadow.show{
  display: block;
}

@media (max-width: 1000px) {
  .gallery .image{
    width: calc(100% / 3);
  }
}
@media (max-width: 800px) {
  .gallery .image{
    width: calc(100% / 2);
  }
}
@media (max-width: 700px) {
  .wrapper nav .items{
    max-width: 600px;
  }
  nav .items span{
    padding: 7px 15px;
  }
}
@media (max-width: 600px) {
  .wrapper{
    margin: 30px auto;
  }
  .wrapper nav .items{
    flex-wrap: wrap;
    justify-content: center;
  }
  nav .items span{
    margin: 5px;
  }
  .gallery .image{
    width: 100%;
  }
}

    	</style>
</head>
<body>
    	<?php include 'include_File/header.php';?>
    <section class="pager-sec">
		<div class="container">
			<ul class="pager-info">
				<li> <a href="#" title="">Home</a></li>
				<li><span>Photo Gallery</span></li>
			</ul><!--pager-info end-->
		</div>
	</section><!---pager-sec end-->


	<div class="page-content p-0">
		
		<section class="block gallery_sec">
			<div class="container">
				<div class="sec-title">
				
					<h2>Our Photo Gallery</h2>
					<p>At Heating & Cooling, we take a lot of pride in the work that we complete for our clients. Below we have included photos from some of our most recent commercial and residential HVAC projects.</p>
				</div><!--sec-title end-->
			</div>
			<div class="gallery-sec">
			         <div class="wrapper">
    <!-- filter Items -->
    <nav>
      <div class="items">
        <span class="item active" data-name="all">All</span>
        <span class="item" data-name="client">Our Clients</span>
        <span class="item" data-name="bag">Teams</span>
        <span class="item" data-name="shoe">Gun Man</span>
        <span class="item" data-name="watch">Recent Projects</span>
        <span class="item" data-name="camera">2016</span>
        <span class="item" data-name="headphone">2017</span>
        
      </div>
    </nav>
    <!-- filter Images -->
    <div class="gallery">
      <div class="image" data-name="client"><span><img src="images/1%20(1)_result.webp" alt=""></span></div>
      <div class="image" data-name="client"><span><img src="images/1%20(2)_result.webp" alt=""></span></div>
      <div class="image" data-name="client"><span><img src="images/1%20(3)_result.webp" alt=""></span></div>
      <div class="image" data-name="client"><span><img src="images/1%20(4)_result.webp" alt=""></span></div>
      <div class="image" data-name="client"><span><img src="images/1%20(5)_result.webp" alt=""></span></div>
      <div class="image" data-name="client"><span><img src="images/1%20(6)_result.webp" alt=""></span></div>
      <div class="image" data-name="client"><span><img src="images/1%20(7)_result.webp" alt=""></span></div>
      <div class="image" data-name="client"><span><img src="images/1%20(8)_result.webp" alt=""></span></div>
      <div class="image" data-name="client"><span><img src="images/1%20(9)_result.webp" alt=""></span></div>
      <div class="image" data-name="client"><span><img src="images/1%20(10)_result.webp" alt=""></span></div>
      <div class="image" data-name="client"><span><img src="images/1%20(11)_result.webp" alt=""></span></div>
      <div class="image" data-name="client"><span><img src="images/1%20(12)_result.webp" alt=""></span></div>
      <div class="image" data-name="client"><span><img src="images/1%20(12)_result.webp" alt=""></span></div>
      
      
      <!--<div class="image" data-name="bag"><span><img src="images/1%20(1)_result.webp" alt=""></span></div>-->
      <!--<div class="image" data-name="headphone"><span><img src="images/1%20(1)_result.webp" alt=""></span></div>-->
      <!--<div class="image" data-name="camera"><span><img src="images/1%20(1)_result.webp" alt=""></span></div>-->
      <!--<div class="image" data-name="shoe"><span><img src="images/1%20(1)_result.webp" alt=""></span></div>-->
      <!--<div class="image" data-name="headphone"><span><img src="images/1%20(1)_result.webp" alt=""></span></div>-->
      <!--<div class="image" data-name="watch"><span><img src="images/1%20(1)_result.webp" alt=""></span></div>-->
      <!--<div class="image" data-name="shoe"><span><img src="images/1%20(1)_result.webp" alt=""></span></div>-->
      <!--<div class="image" data-name="camera"><span><img src="images/1%20(1)_result.webp" alt=""></span></div>-->
    </div>
  </div>
  <!-- fullscreen img preview box -->
  <div class="preview-box">
    <div class="details">
      <span class="title">Image Category: <p></p></span>
      <span class="icon fas fa-times"></span>
    </div>
    <div class="image-box"><img src="" alt=""></div>
  </div>
  <div class="shadow"></div>
		    </div><!--gallery-sec end-->
		
		</section>
			<?php include 'include_File/footer.php';?>
</body>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>

	<script type="text/javascript" src="js/gallery.js"></script>

	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/moment.min.js"></script>
	<script type="text/javascript" src="js/bootstrap-datetimepicker.min.js"></script>
	<script type="text/javascript" src="js/jquery.form.js"></script>
	<script type="text/javascript" src="js/jquery.validate.min.js"></script>
	<script type="text/javascript" src="js/slick.min.js"></script>
	<script type="text/javascript" src="js/custom-tabs.js"></script>
	<script type="text/javascript" src="js/forms.js"></script>
	<script type="text/javascript" src="js/scripts.js"></script>
	<script type="text/javascript" src="js/main.js"></script> 
	<script type="text/javascript" src="js/main1.js"></script> 
	<script src="js/jquery.magnific-popup.js"></script>
	<script type="text/javascript" src="js/isotope.pkgd.js"></script>

</html>