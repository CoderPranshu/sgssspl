<!DOCTYPE html>
<html lang="en">

<head>
	<?php include 'include_File/head.php';?>
<style>
#more {display: none;}
.preloader1 {
  background-color: #fff;
  bottom: 0;
  height: 100%;
  left: 0;
  position: fixed;
  right: 0;
  top: 0;
  width: 100%;
  z-index: 9999; }

.lds-ellipsis {
  margin: 0 auto;
  position: relative;
  top: 50%;
  -moz-transform: translateY(-50%);
  -webkit-transform: translateY(-50%);
  transform: translateY(-50%);
  width: 360px;
  text-align: center;
  z-index: 9999; }

.lds-ellipsis span {
  display: inline-block;
  width: 50px;
  height: 50px;
  /*border-radius: 50%;*/
  /*background-image:url('../images/pre_result.webp');*/
  /*background: #fed700;*/
  -webkit-animation: ball-pulse-sync .6s 0s infinite ease-in-out;
  animation: ball-pulse-sync .6s 0s infinite ease-in-out; }

.lds-ellipsis span:nth-child(1) {
  -webkit-animation: ball-pulse-sync .6s -.14s infinite ease-in-out;
  animation: ball-pulse-sync 0.6s -0.14s infinite ease-in-out; }

.lds-ellipsis span:nth-child(2) {
  -webkit-animation: ball-pulse-sync .6s -70ms infinite ease-in-out;
  animation: ball-pulse-sync 0.6s -70ms infinite ease-in-out; }
  .lds-ellipsis span:nth-child(3) {
  -webkit-animation: ball-pulse-sync .6s -90ms infinite ease-in-out;
  animation: ball-pulse-sync 0.6s -90ms infinite ease-in-out; }
  .lds-ellipsis span:nth-child(4) {
  -webkit-animation: ball-pulse-sync .6s -110ms infinite ease-in-out;
  animation: ball-pulse-sync 0.6s -110ms infinite ease-in-out; }
  
  
@media(min-width:600px) {
  hiddenk{
    visibility: hidden;
    display: none;
  }
}  


@-webkit-keyframes ball-pulse-sync {
  33% {
    -webkit-transform: translateY(10px);
    transform: translateY(10px); }
  66% {
    -webkit-transform: translateY(-10px);
    transform: translateY(-10px); }
  100% {
    -webkit-transform: translateY(0);
    transform: translateY(0); } }
@keyframes ball-pulse-sync {
  33% {
    -webkit-transform: translateY(10px);
    transform: translateY(10px); }
  66% {
    -webkit-transform: translateY(-10px);
    transform: translateY(-10px); }
  100% {
    -webkit-transform: translateY(0);
    transform: translateY(0); } }

.banner-slide{
    height:auto;
}

</style>
</head>

<body class="home layout2">
    
   <!--<div class="preloader1">-->
   <!--     <div class="lds-ellipsis">-->
   <!--         <span style="background-image:url('../images/s1_result.webp');"></span>-->
   <!--         <span style="background-image:url('../images/g1_result.webp');"></span>-->
   <!--         <span style="background-image:url('../images/s1_result.webp');"></span>-->
   <!--          <span style="background-image:url('../images/s1_result.webp');"></span>-->
   <!--          <span style="background-image:url('../images/p1_result.webp');"></span>-->
   <!--          <span style="background-image:url('../images/l1_result.webp');"></span>-->
            
   <!--     </div>-->
   <!-- </div>-->
	
	<?php include 'include_File/header.php';?>


	<!--responsive-menu end-->


	<div class="banner-section">
		<div class="banner-slider"  >
			<div class="banner-slide"  >
				<img src="images/banner-img1_result.webp" alt="">
				<div class="fig_text">
					<h3>Get High Securtiy At</h3>
					<h2>Your Home 24/7!</h2>
				</div>
				<!--fig_text end-->
			</div>
			<!--banner-slide add new end-->
			<div class="banner-slide" >
				<img src="images/sliderIMG-20211211-WA0005.webp"  alt>
				<div class="fig_text">
					<h3>Get High Securtiy At</h3>
					<h2>Call us Now</h2>
				</div>
				<!--fig_text end-->
			</div>
			<!--banner-slide end-->
			<div class="banner-slide" >
				<img src="images/banner-img3_result123.webp"  alt>
				<div class="fig_text">
					<h3>Get High Securtiy At</h3>
					<h2>Your Home 24/7!</h2>
				</div>
				<!--fig_text end-->
			</div>
			<!--banner-slide end-->
			<div class="banner-slide" >
				<img src="images/banner-img3_result123.webp"  alt>
				<div class="fig_text">
					<h3>Best ASO & PSO </h3>
					<h2>Call-011-4022-4969</h2>
				</div>
				<!--fig_text end-->
			</div>
			<!--banner-slide end-->
		</div>
		<!--banner-slider end-->
		
		<!--fgt-logo end-->
		<div class="fig_sec" style="display: none;">
		</div>
		<!--fig_sec end-->
	</div>
	<!--banner-section end-->

	<section class="welcome-section">
	
		<div class="container">
		  
		  <div class="section-title-center">
			<p>Welcome</p>
			<h4>About</h4>
			<h2>Our Company</h2>
			<div class="text"><span style="font-weight:bold;">SUPER GLOBAL SEFTY SECURITY SERVICES PVT. LTD. </span>People believe that theperformance of an organisation is solely dependent
			on the quality of its personnel and that our people are, indeed, our greatest strength. Consequently we invest heavily on our humand resources in order to
			keep them abreast with the changing trends in the security industry, for a better and secure environment for our clients. By providing fair and decent rates
			of pay and terms & conditions of employment we keep our entire workiorce happy, so that, in turn, they keep you secure. 
 </div>
		  </div>
		 
		  
		  <div class="row">
		
			<div class="col-lg-4 col-md-5 col-sm-6 col-xs-12">
			 
			  <article class="icon-box text-right right mar-blg wow fadeInLeft" data-wow-delay="0.6s"
				style="visibility:visible; animation-delay: 0.6s; animation-name: fadeInLeft;"> 
				<h2>Security Guards</h2>
				<p>Lorem ipsum dolor sit amet, velit urna. Metus ornare est erat feugiat egestas vulputate. Lectus litora
				  nascetur nunc.</p>
			  </article>
			  
			  <article class="icon-box text-right right mar-blg wow fadeInLeft" data-wow-delay="0.6s"
				style="visibility:visible; animation-delay: 0.6s; animation-name: fadeInLeft;">
				<h2>Petrol Guards</h2>
				<p>Lorem ipsum dolor sit amet, velit urna lorem ipsum dolor sit amet, velit urna. Metus ornare est erat
				  feugiat egestas vulputate. Lectus litora nascetur nunc.</p>
			  </article>
			  
			  <article class="icon-box text-right right mar-blg wow fadeInLeft" data-wow-delay="0.6s"
				style="visibility:visible; animation-delay: 0.6s; animation-name: fadeInLeft;"> 
				<h2>Marshals</h2>
				<p>Lorem ipsum dolor sit amet, velit urna. Metus ornare est erat feugiat egestas vulputate. Lectus litora
				  nascetur nunc.</p>
			  </article>
			 
			</div>
		
			<div class="col-lg-4 col-md-2">
			  
			  <div class="about-img"><img alt="about-img" src="images/1633970160840_result.webp" style="padding: 0 40px 40px 40px;"></div>
			 
			</div>
		
			<div class="col-lg-4 col-md-5 col-sm-6 col-xs-12">
			  
			  <article class="icon-box mar-blg wow fadeInRight" data-wow-delay="0.6s"
				style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInRight
				<h2>Bouncers</h2>
				<p>Lorem ipsum dolor sit amet, velit urna lorem ipsum dolor sit amet, velit urna. Metus ornare est erat
				  feugiat egestas vulputate. Lectus litora nascetur nunc.</p>
			  </article>
			  
			  <article class="icon-box mar-blg wow fadeInRight" data-wow-delay="0.6s"
				style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInRight;"> 
				<h2>Personal Security Officers</h2>
				<p>Lorem ipsum dolor sit amet, velit urna. Metus ornare est erat feugiat egestas vulputate. Lectus litora
				  nascetur nunc.</p>
			  </article>
			  
			  <article class="icon-box mar-blg wow fadeInRight" data-wow-delay="0.6s"
				style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInRight;"> 
				<h2>Detective Service</h2>
				<p>Lorem ipsum dolor sit amet, velit urna lorem ipsum dolor sit amet, velit urna. Metus ornare est erat
				  feugiat</p>
			  </article>
			  
			  <article class="icon-box mar-blg wow fadeInRight" data-wow-delay="0.6s"
				style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInRight;"> 
				<h2>House keeper</h2>
				<p>Lorem ipsum dolor sit amet, velit urna lorem ipsum dolor sit amet, velit urna. Metus ornare est erat
				  feugiat</p>
			  </article>
			  
	
			</div>
		
		  </div>
		 
		</div>
		
	  </section>
				
	<div class="about-us-area about-bg" id=hide1>
		<h1 style="font-size: 38px;	font-weight: bold; text-align: center; padding-top: 40px;"><span style="color:#FFBF21;">About </span>Our Company</h1>
		<p style="font-size: 16px;	font-weight: bold; text-align: center;">sanctus est Lorem ipsum</p>

		<div class="container-fluid">
			<div class="row justify-content-start">
				<div class="col-lg-5 remove-col-padding">
					<div class="about-image">
						<img src="images/about-bg_result.webp" style="height:400px; width:570px;" class="img-fluid" alt="about image">
						<div class="hover">
							<a href="https://www.youtube.com/watch?v=s6NHxfKUkUo" target="_blank" class="btn-ripple-animate video-play-btn video mfp-iframe">
								<i class="fa fa-play"></i>
							</a>
						</div>
					</div>
				</div>
				<div class="col-lg-7 align-self-center">
					<div class="about-area-right mb-0">
						
					<div class="ht-accordion active toggle" id="ques_accordion">
						<div class="toggle-item">
							<h2>COMPANY PROFILE</h2>
							<div class="content">
								<p>SUPER GLOBAL SEFTY SECURITY SERVICES PVT. LTD. is a leading security and housekeeping company capable of meeting all security needs of its client, to their entire satisfaction. We have a good team of professionals for providing reliable and cost-effective security solutions for the protection of life and property. A correct blend of skills and resources developed and perfected by us, has enabled us to provide unparallel and intensive security services to some of the highly reputed and well-known industries and big institutions. <span><a href="http://sgsspl.com/companyprofile.php">Read More..</a></span>  </p>
							</div>
						</div><!-- Toggle Item -->
						<div class="toggle-item">
							<h2>PROCESS OF RECRUITMENT</h2>
							<div class="content">
								<p>We keep the completer credentials of each every along with 2-3 securities and the original high school certificate. A verification form is deposited with Police Station and a copy of verification report is maintained so as to strengthen the facts of information about the personnel hired. Two photographs of the personnel are also kept in our records for proper identification. <span class="text-white"><a href="http://sgsspl.com/process.php">Read More..</a></span> </p>
							</div>
						</div><!-- Toggle Item -->
						<div class="toggle-item">
							<h2>QUALITY</h2>
							<div class="content">
								<p>SUPER GLOBAL SEFTY SECURITY SERVICES PVT. LTD. People believe that the performance of an organisation is solely dependent on the quality of its personnel and that our people are, indeed, our greatest strength. Consequently, we invest heavily on our human resources in order to keep them abreast with the changing trends in the security industry, for a better and secure environment for our clients. By providing fair and decent rates of pay and terms & conditions of employment we keep our entire workers happy, so that, in turn, they keep you secure.
At SUPER GLOBAL SEFTY SECURITY SERVICES PVT. LTD. Regd. we have adopted the Total Quality Management (TQM) concept which can be condensed into the following doctrines. </p>
							</div>
						</div><!-- Toggle Item -->
						
					</div><!-- ht-accordion Accordion -->
					
					
						
						<div class="btn-wrapper">
							<a href="http://sgsspl.com/about.php" class="btn-hrv">More About Here</a>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>

<section class="block service-block">
		<div class="container">
			<div class="sec-title">
				<h4>Open 24/7 with office staff</h4>
				<h2>How Can We Help You?</h2>
			</div>
			<!--sec-title end-->
		</div>
		<div class="choose_services_sec">
			<h5>Choose your service</h5>
			<ul class="tabs_list">
				<li style="border-radius: 20px 0px 0px 20px;" class="active" data-tab="cooling_sli">
					<img src="images/01-ico-guard_result.webp" style="width:40px; height:40px">
					<span style="top: -1px;" class="svs">Security Guard</span>
				</li>
				<li class="hea ting" data-tab="pso">
				     <img src="images/02-ico-supervisor_result.webp" style="width:40px; height:40px">
					<span style="top: -1px;"  class="svs">Security Supervisor</span>
				
					   
				
				</li>
				<li class="hea ting" data-tab="gunman">
				     <img src="images/03-ico-gunman_result.webp" style="width:40px; height:40px">
					<span style="top: -1px;"  class="svs">Gun Man</span>
				
				</li>
				<li class="hea ting" data-tab="pso">
				 <img src="images/04-ico-aso_result.webp" style="width:40px; height:40px">
					<span style="top: -1px;"  class="svs">PSO</span>
				
				</li>
				<li style="border-radius: 0px 20px 20px 0px;" class="hea ting" data-tab="pso">
				 <img src="images/05-ico-bouncers_result.webp" style="width:40px; height:40px">
					<span style="top: -1px;"  class="svs">Bouncers</span>
				
				</li>
				
			</ul>
			<!--tabs_list end-->
			<div class="srvs_slider active" id="cooling_sli">
				<div class="srvs_dv">
					<img src="images/4499621_result.webp" alt>
					<h2 class="srvs_heading">Gaurd</h2>
					<div class="srvs_details">
						<h3>Gaurd</h3>
						
					</div>
				</div>
				<!--srvs_dv end-->
				<div class="srvs_dv">
					<img src="images/4499620_result.webp" alt>
					<h2 class="srvs_heading">Gaurd</h2>
					<div class="srvs_details">
						<h3>Air Gaurd</h3>
						
					</div>
				</div>
				<!--srvs_dv end-->
				<div class="srvs_dv">
					<img src="images/123456_result.webp" alt>
					<h2 class="srvs_heading">Gaurd Services</h2>
					<div class="srvs_details">
						<h3>Gaurd</h3>
						
					</div>
				</div>
				<!--srvs_dv end-->
				<div class="srvs_dv">
					<img src="images/1234567_result.webp" alt>
					<h2 class="srvs_heading">Gaurd</h2>
					<div class="srvs_details">
						<h3>Gaurd</h3>
						
					</div>
				</div>
				<!--srvs_dv end-->
				
				<!--srvs_dv end-->
				<div class="srvs_dv">
					<img src="images/4499620_result.webp" alt>
					<h2 class="srvs_heading">Gaurd</h2>
					<div class="srvs_details">
						<h3>Gaurd</h3>
						
					</div>
				</div>
				<!--srvs_dv end-->
			</div>
			<!--srvs_slider end-->
			<div class="srvs_slider" id="gunman">
				<div class="srvs_dv">
					<img src="images/IMG_4101_result.webp" alt>
					<h2 class="srvs_heading">Gaurd</h2>
					<div class="srvs_details">
						<h3>Gaurd</h3>
						
					</div>
				</div>
				<!--srvs_dv end-->
				<div class="srvs_dv">
					<img src="images/IMG_4076_result.webp" alt>
					<h2 class="srvs_heading">Gaurd</h2>
					<div class="srvs_details">
						<h3>Gaurd</h3>
						
					</div>
				</div>
				<!--srvs_dv end-->
				<div class="srvs_dv">
					<img src="images/IMG_4068_result.webp" alt>
					<h2 class="srvs_heading">FGaurd</h2>
					<div class="srvs_details">
						<h3>Gaurd</h3>
						
					</div>
				</div>
				<!--srvs_dv end-->
				<div class="srvs_dv">
					<img src="images/IMG_4058_result.webp" alt>
					<h2 class="srvs_heading">Gaurd</h2>
					<div class="srvs_details">
						<h3>Gaurd</h3>
						
					</div>
				</div>
								<div class="srvs_dv">
					<img src="images/IMG-20211213-WA0007.webp" alt>
					<h2 class="srvs_heading">Gun Man</h2>
					<div class="srvs_details">
						<h3>Gaurd</h3>
						
					</div>
				</div>
			
			</div>
			<!--srvs_slider end-->
				<div class="srvs_slider" id="pso">
				<div class="srvs_dv">
					<img src="images/IMG_4101_result.webp" alt>
					<h2 class="srvs_heading">Gaurd</h2>
					<div class="srvs_details">
						<h3>Gaurd</h3>
						
					</div>
				</div>
				<!--srvs_dv end-->
				<div class="srvs_dv">
					<img src="images/IMG_4091_result.webp" alt>
					<h2 class="srvs_heading">Gaurd</h2>
					<div class="srvs_details">
						<h3>Gaurd</h3>
						
					</div>
				</div>
				<!--srvs_dv end-->
				<div class="srvs_dv">
					<img src="images/IMG_4091_result.webp" alt>
					<h2 class="srvs_heading">FGaurd</h2>
					<div class="srvs_details">
						<h3>Gaurd</h3>
						
					</div>
				</div>
				<!--srvs_dv end-->
				<div class="srvs_dv">
					<img src="images/IMG_4107_result.webp" alt>
					<h2 class="srvs_heading">Gaurd</h2>
					<div class="srvs_details">
						<h3>Gaurd</h3>
						
					</div>
				</div>
			
			</div>
		</div>
		<!--choose_services_sec end-->
	</section>
	<section class="block sap-sec air_sec hiddenk">
		<div class="fixed-bg bg4"></div>
		<div class="container">
			<div class="sep-text">
				<h2><span>Super Global Sefty </span> Security Services</h2>
				<p>Any Requirment Middle of the night Give us a call anytime. We're ready.</p>
				<a href="#"  class="lnk_default ">Make an Appointment</a>
			</div><!--sep-text end-->
		</div>
	</section><!--sap-sec end-->
	<section class="block team_sec">
			<div class="container">
				<div class="sec-title">
					<h4>Get to know the great people</h4>
					<h2>Our Team</h2>
				</div><!--sec-title end-->
				<div class="team-sec">
					<div class="row team_carousel">
						<div class="col-lg-4">
							<div class="team">
								<div class="team_img">
									<img src="images/IMG_4081_result.webp" alt="">
								</div><!--team_img end-->
								<h3>D.P.SINGH</h3>
								<h4></h4>
								<p> </p>
							</div><!--team end-->
						</div>
					
						<div class="col-lg-4">
							<div class="team">
								<div class="team_img">
									<img src="images/IMG_4089_result.webp" alt="">
								</div><!--team_img end-->
								<h3>JITENDRA KUMAR SINGH</h3>
								<h4></h4>
								<p> </p>
							</div><!--team end-->
						</div>
						<div class="col-lg-4">
							<div class="team">
								<div class="team_img">
									<img src="images/IMG_4145_result.webp" alt="">
								</div><!--team_img end-->
								<h3>BHARAT SINGH</h3>
								<h4></h4>
								<p> </p>
							</div><!--team end-->
						</div>
						<div class="col-lg-4">
							<div class="team">
								<div class="team_img">
									<img src="images/WhatsApp Image 2021-12-17 at 2.29.19 PM.jpeg" alt="">
								</div><!--team_img end-->
								<h3>YOGESH KAUSHIK</h3>
								<h4></h4>
								<p> </p>
							</div><!--team end-->
						</div>
						<div class="col-lg-4">
							<div class="team">
								<div class="team_img">
									<img src="images/IMG_4139_result.webp" alt="">
								</div><!--team_img end-->
								<h3>SANDEEP MISHRA</h3>
								<h4></h4>
								<p>  </p>
							</div><!--team end-->
						</div>
						<div class="col-lg-4">
							<div class="team">
								<div class="team_img">
									<img src="images/IMG_4146_result.webp" alt="">
								</div><!--team_img end-->
								<h3>ARUN KUMAR</h3>
								<h4></h4>
								<p></p>
							</div><!--team end-->
						</div>
					</div>
				</div><!--team-sec end-->
			</div>
		</section><!--team-sec end-->
	


	

	<div class="featured-area section-space-88-100">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="section-title-area">
						<h2 class="section-title">Featured Works</h2>
						<div class="title-bottom-icon">
							<span class="title-bottom-icon-left"></span>
							<i class="fa fa-cubes" aria-hidden="true"></i>
							<span class="title-bottom-icon-right"></span>
						</div>
					</div>
				</div>
			</div>
			<div class="row inner-section-space-top">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="isotop-classes-tab">                           
					
						
					</div>
				</div>
			</div>
		</div> 
		<div style="overflow-x: hidden;" class="container-fluid ">
			<div class="row featuredContainer">
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 Interior Digging Tiling">
					<div class="featured-box">
						
						<ul class="featured-details">
							<li><a href="images/1%20(1).jpeg" class="zoom" rel="gal"><i class="fa fa-search" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-link" aria-hidden="true"></i></a></li>
						</ul> 
						<div class=""></div>
						<a href="#"><img src="images/1%20(1).jpeg" alt="featured3"></a>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 Buildings Digging Tiling">
					<div class="featured-box">
						
						<ul class="featured-details">
							<li><a href="images/1%20(2).jpeg" class="zoom" rel="gal"><i class="fa fa-search" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-link" aria-hidden="true"></i></a></li>
						</ul> 
						<div class=""></div>
						<a href="#"><img src="images/1%20(2).jpeg" alt="featured3"></a>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 Buildings Interior Digging Construction">
					<div class="featured-box">
						
						<ul class="featured-details">
							<li><a href="images/1%20(3).jpeg" class="zoom" rel="gal"><i class="fa fa-search" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-link" aria-hidden="true"></i></a></li>
						</ul> 
						<div class=""></div>
						<a href="#"><img src="images/1%20(3).jpeg" alt="featured3"></a>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 Buildings Construction Interior">
					<div class="featured-box">
					
						<ul class="featured-details">
							<li><a href="images/1%20(4).jpeg" class="zoom" rel="gal"><i class="fa fa-search" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-link" aria-hidden="true"></i></a></li>
						</ul> 
						<div class=""></div>
						<a href="#"><img src="images/1%20(4).jpeg" alt="featured3"></a>
					</div>
				</div>
				
			</div>
		</div>
	</div>
		


    <div class="call-us-area">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="call-contact">
                        <h3>Call Us 24/7</h3>
                        <a href="tel:+919540328830" class="call-btn">+91-9540328830</a>
                        <p>At SUPER GLOBAL SEFTY SECURITY SERVICES PVT. LTD. Regd. we have adopted the Total Quality Management (TQM) concept which cna be condensed into the following doctrines. </p>
                       <p>
                        ► To primary responsibility of quality lies with the guarddoing the work,  but management of quality is crucial  to company survival and merits the<span id="dots">...</span><span id="more">  attention and commitment of top management.
                        <br><br>► To enable the operation department to accept the  responsibility of quality, management of must establish systems. These systems should be able to control and verify service and must educate and indoctrinate the workforce in its operations.
                       <br><br>► The cost of training and supervision and other cost incurred for quality are repaid many times over by increased clientele, prevention of loss of contracts, higher profits, a quality product a n d Most importantly - a better life for its users. 

                        </span>
                        </p>
                        <button class="btn btn-primary" onclick="myFunction()" id="myBtn">Read more</button>
                        
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="call-us-img">
                        <img src="images/k1633971490820_result.webp" alt="Images"style=" margin-top:-100px;"
                           >
                        <div class="call-shape">
                            <!--<div class="shape1">-->
                            <!--    <img src="images/call-shap2_result.webp" alt="Images"-->
                            <!--        >-->
                            <!--</div>-->
                            <!--<div class="shape2">-->
                            <!--    <img src="images/call-shap3_result.webp" alt="Images"  >-->
                            <!--</div>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<section class="" style="padding-top:60px;">
		<div class="">
			<div class="sec-title">
				<h4>Get Direction</h4>
				<h2>Our Location</h2>
			</div>
			<!--sec-title end-->

			<!--pt_carousel end-->
		</div>
	</section>

	<!--partners-sec end-->


	<!--newsletter-sec end-->


	




<?php include 'include_File/footer.php';?>

	<a href="#" title class="scrollTop"><i class="fa fa-long-arrow-up"></i></a>



	<script>
	
   $(window).load(function(){
	   var $container = $('.featuredContainer');
	   $container.isotope({
		   filter: '*',
		   animationOptions: {
		   duration: 750,
		   easing: 'linear',
		   queue: false
		   }
	   });
	   $('.isotop-classes-tab').on('click', 'a',function(){
		   $('.isotop-classes-tab .current').removeClass('current');
		   $(this).addClass('current');
		   var selector = $(this).attr('data-filter');
		   $container.isotope({
			   filter: selector,
			   animationOptions: {
			   duration: 750,
			   easing: 'linear',
			   queue: false
			   }
			});
			return false;
	   });
   });

 
	</script>
	<script type="text/javascript" src="js/jquery-1.12.0.min.js"></script>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/moment.min.js"></script>
	<script type="text/javascript" src="js/bootstrap-datetimepicker.min.js"></script>
	<script type="text/javascript" src="js/jquery.form.js"></script>
	<script type="text/javascript" src="js/jquery.validate.min.js"></script>
	<script type="text/javascript" src="js/slick.min.js"></script>
	<script type="text/javascript" src="js/custom-tabs.js"></script>
	<script type="text/javascript" src="js/forms.js"></script>
	<script type="text/javascript" src="js/scripts.js"></script>
	<script type="text/javascript" src="js/main.js"></script> 
	<script type="text/javascript" src="js/main1.js"></script> 
	<script src="js/jquery.magnific-popup.js"></script>
	<script>
function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
</script>
	<script type="text/javascript" src="js/isotope.pkgd.js"></script>
	<script></script>

</body>

</html>