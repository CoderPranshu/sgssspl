<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'include_File/head.php';?>
</head>

<body class="home layout2">

            	<?php include 'include_File/header.php';?>


	<div class="responsive-header">
		<div class="container">
			<div class="responsive_hd_logo">
				<a href="index.html" title="">
					<img src="images/logo2.png" alt="">
				</a>
			</div><!--responsive_hd_logo end-->
			<div class="responsive_header_navigations">
				<nav>
					<ul>
						<li><a href="index.html" title="">Home</a></li>
						<li><a href="about_page.html" title="">About us</a></li>
						<li><a class="active" href="services_page.html" title="">services</a>
							<ul>
								<li><a href="services_single.html" title="">Service Single</a></li>
							</ul>
						</li>
						<li><a href="price_page.html" title="">prices</a></li>
						<li><a href="gallery_page.html" title="">gallery</a></li>
						<li><a href="blog_posts_page.html" title="">blog</a>
							<ul>
								<li><a href="blog_single_post_page.html" title="">Blog Single</a></li>
							</ul>
						</li>
						<li><a href="faqs_page.html" title="">faqs</a></li>
						<li><a href="contact_page.html" title="">Contact us</a></li>
					</ul>
				</nav>
			</div><!--responsive_header_navigations end-->
			<a href="#" title="" class="menu_btn">
				<svg version="1.1" id="Layer_3" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					 viewBox="0 0 512 512"  xml:space="preserve">
				<g>
					<g>
						<path d="M491.318,235.318H20.682C9.26,235.318,0,244.577,0,256s9.26,20.682,20.682,20.682h470.636
							c11.423,0,20.682-9.259,20.682-20.682C512,244.578,502.741,235.318,491.318,235.318z"/>
					</g>
				</g>
				<g>
					<g>
						<path d="M491.318,78.439H20.682C9.26,78.439,0,87.699,0,99.121c0,11.422,9.26,20.682,20.682,20.682h470.636
							c11.423,0,20.682-9.26,20.682-20.682C512,87.699,502.741,78.439,491.318,78.439z"/>
					</g>
				</g>
				<g>
					<g>
						<path d="M491.318,392.197H20.682C9.26,392.197,0,401.456,0,412.879s9.26,20.682,20.682,20.682h470.636
							c11.423,0,20.682-9.259,20.682-20.682S502.741,392.197,491.318,392.197z"/>
					</g>
				</g>
				</svg>
					</a>
			<div class="clearfix"></div>
		</div>
	</div><!--responsive-header end-->

	<div class="responsive-menu">
		<a href="#" title="" class="close-mobile-menu"><img src="images/close.png" alt=""></a>
		<ul>
			<li><a href="index.html" title="">HOME</a></li>
			<li><a href="about_page.html" title="">About us</a></li>
			<li><a class="active" href="#" title="">Services</a>
				<ul>
					<li><a href="services_page.html" title="">Services</a></li>
					<li><a class="active" href="services_single.html" title="">Services Single</a></li>
				</ul>
			</li>
			<li><a href="price_page.html" title="">Prices</a></li>
			<li><a href="gallery_page.html" title="">Gallery</a></li>
			<li><a href="#" title="">blog</a>
				<ul>
					<li><a href="blog_posts_page.html" title="">Blog</a></li>
					<li><a href="blog_single_post_page.html" title="">Blog Single</a></li>
				</ul>
			</li>
			<li><a href="faqs_page.html" title="">faqs</a></li>
			<li><a href="contact_page.html" title="">contact us</a></li>
		</ul>
	</div><!--responsive-menu end-->

	<section class="pager-sec">
		<div class="container">
			<ul class="pager-info">
				<li> <a href="#" title="">Home</a></li>
				<li><span>Services</span></li>
			</ul><!--pager-info end-->
		</div>
	</section><!---pager-sec end-->


	<div class="page-content p-0">
		
		<section class="block tp-100">
			<div class="container">
				<div class="service_single_page">
					<div class="row">
						<div class="col-lg-9 col-md-9 pull-right">
							<div class="service-single-details">
								<div class="service-single">
									<h2>Bouncers</h2>
									<img src="http://websmirno.site/kax/heatingandcooling/images/resources/service-img.jpg" alt="">
									<h3>High Efficient Ac Installation, A/c Installation & Air Conditioning Installation</h3>
									<p>Central air conditioning allows you to enjoy the perfect temperature in any room of your house. Bedrooms can be kept refreshingly cool even on the stickiest summer nights. You’ll benefit from ideal sleeping conditions, complete humidity control, and a fresher, cleaner home. Through effective, air-purifying filtration systems, cooling units also reduce bacteria, dust, house mites, mold, pet dander and pollen, proving extremely beneficial for those who suffer from allergies and respiratory problems. </p>
									<p> When you’re ready to experience your summer in a whole new way, call Heating & Cooling for air conditioning installation, and we’ll exceed your expectations.</p>
									<h3>Expert AC Replacement</h3>
									<p>At Heating & Cooling we are committed to doing the job right. As a Factory Authorized Dealer, our technicians are NATE-certified professionals who have completed a demanding set of core and specialty exams to ensure their technical competency. They also continue training specific to Carrier technology and products. We are fully bonded and insured, offer free in-home estimates and convenient financing options.  As family owned and operated business since 2010, we’ve served the comfort needs of Pittsburgh and the surrounding areas with a dedication to providing the best prices for the very best service.</p>
									<p> When it comes to managing indoor humidity, the two-stage compressor makes a significant comfort difference, allowing the system to function mostly in low-stage, where you achieve the highest efficiency.  A filter drier system protects against moisture and contaminants while compressor sound blanket keeps operational noise down to 65 decibels.</p>
									<h3>Top Quality Air Conditioning Installation</h3>
									<p>By installing an air conditioning system that has met the standards set by the Environmental Protection Agency, you stand to save 30% on cooling bills each year. </p>
								
								</div><!--service-single end-->
								<div class="service-svv">
									<div class="svv-img">
										<img src="http://websmirno.site/kax/heatingandcooling/images/resources/vc.png" alt="">
									</div>
									<div class="svv-info">
										<h3>Peace of mind for you and your family.</h3>
										<p>Cooling & Heating has been repairing AC systems for more than 10 years. We want you to be cool and comfortable, and we’ll guarantee any repairs we make through a one-year warranty.</p>
									</div><!--svv-info end-->
								</div><!--service-svv end-->
							</div>
						</div>
						<div class="col-lg-3 col-md-3 ful_wd pull-left">
							<div class="side_bar">
								<div class="dvis">
									<ul style="padding-top: 80px;" class="tabs_list">
										
										<li onclick="location.href='service.php'" class="active heating" data-tab="hea_ting">
										    	<span style="padding-left:20px" class="tc_ icon">
																							
																							  <img src="images/01-ico-guard.png" style="width:40px; height:50px; padding-bottom: 10px;">
											</span>
											<span class="svs">Security Guard</span>
										</li>
								        	<li onclick="location.href='securitysupervisor.php'" class="active heating" data-tab="hea_ting">
											<span style="padding-left:20px" class="tc_ icon">
												  <img src="images/02-ico-supervisor.png" style="width:40px; height:50px; padding-bottom: 10px;">
											</span>
											<span style="top: -0.1px;" class="svs">Security Supervisor</span>
										</li>
									<li onclick="location.href='gunman.php'" class="active heating" data-tab="hea_ting">
											<span style="padding-left:20px" class="tc_ icon">
																							  <img src="images/03-ico-gunman.png" style="width:40px; height:50px; padding-bottom: 10px;">
											</span>
											<span style="top: -0.1px;" class="svs">Gun Man</span>
										</li>
									<li onclick="location.href='aso.php'" class="active heating" data-tab="hea_ting">
											<span style="padding-left:20px" class="tc_ icon">
																							  <img src="images/04-ico-aso.png" style="width:40px; height:50px; padding-bottom: 10px;">
											</span>
											<span style="top: -0.1px;" class="svs">ASO</span>
										</li>
									<li onclick="location.href='bouncers.php'" class="active heating" data-tab="hea_ting">
											<span style="padding-left:20px" class="tc_ icon">
																							  <img src="images/05-ico-bouncers.png" style="width:40px; height:50px; padding-bottom: 10px;">
											</span>
											<span style="top: -0.1px;" class="svs">Bouncers</span>
										</li>
									<li onclick="location.href='armedpso.php'" class="active heating" data-tab="hea_ting">
											<span style="padding-left:20px" class="tc_ icon">
																							  <img src="images/ico-armed-pso90px.png" style="width:40px; height:50px; padding-bottom: 10px;">
											</span>
											<span style="top: -0.1px;" class="svs">Armed PSO</span>
										</li>
									<li onclick="location.href='firesafetyexpert.php'" class="active heating" data-tab="hea_ting">
											<span style="padding-left:20px" class="tc_ icon">
																							  <img src="images/07-ico-fire.png" style="width:40px; height:50px; padding-bottom: 10px;">
											</span>
											<span style="top: -0.1px;" class="svs">Fire Safety Expert</span>
										</li>
									<li onclick="location.href='surveillancerooms.php'" class="active heating" data-tab="hea_ting">
											<span style="padding-left:20px" class="tc_ icon">
																							  <img src="images/08-ico-surv.png" style="width:40px; height:50px; padding-bottom: 10px;">
											</span>
											<span style="top: -0.1px;" class="svs">Surveillance Rooms</span>
										</li>
									<li onclick="location.href='security.php'" class="active heating" data-tab="hea_ting">
											<span style="padding-left:20px" class="tc_ icon">
																							  <img src="images/pngwing.com (3).png" style="width:40px; height:50px; padding-bottom: 10px;">
											</span>
											<span style="top: -0.1px;" class="svs">Security</span>
										</li>
								
									</ul><!--tabs_list end-->
								
								</div><!--dvis end-->
								<div class="contact_wd">
									<h3>Our Contacts</h3>
									<ul>
										<li>
											<span><i class="fa fa-map-marker"></i></span>
											<h4>1531 Moonlight Drive, Maple Shade, NJ</h4>
										</li>
										<li>
											<span><i class="fa fa-clock-o"></i></span>
											<h4>Monday-Friday <br /> 8:00 am - 8:00 pm</h4>
										</li>
										<li>
											<span><i class="fa fa-phone"></i></span>
											<h4>24/7 Emergency Service: 609-123-4567</h4> 
										</li>
									</ul>
								</div><!--contact_wd end-->
								<div class="ht_form">
									<h3>Ask Question</h3>
									<form id="contactform" name="contactform" method="post" novalidate>
										<div id="success">
											<p>Your message was sent successfully!</p>
										</div>
										<div id="error">
											<p>Something went wrong, try refreshing and submitting the form again.</p>
										</div>
										<div class="input_field">
											<input type="text" name="name" placeholder="Your name">
										</div>
										<div class="input_field">
											<input type="text" name="email" placeholder="Your e-mail">
										</div>
										<div class="input_field">
											<textarea name="message" placeholder="Your question"></textarea>
										</div>
										<div class="submit_btn">
											<input type="submit" id="submit" name="submit" value="Ask Question">
										</div>
									</form>
								</div><!--ht_form end-->
							</div><!--side_bar end-->
						</div>
					</div>
				</div><!--service_single_page end-->
			</div>
		</section>

	</div><!--page-content end-->

	<section class="newsletter-sec">
		<div  class="container">
			<ul class="nss_list">
				<li>
					<span>24/Hour</span> Emergency Service  
				</li>
				<li>
					<span>Free</span> Consultations  
				</li>
				<li>
					Newsletter Subscribe  
				</li>
			</ul><!--nss_list end-->
			<form class="newsletter_form">
				<input type="text" name="search" placeholder="Your e-mail...">
				<input type="submit" name="submit" value="OK">
			</form><!--newsletter_form  end-->
		</div>
	</section><!--newsletter-sec end-->

	<div class="our_map v1">
		<div class="mapouter">
			<iframe id="gmap_canvas4" src="https://maps.google.com/maps?q=university%20of%20san%20francisco&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
		</div>
	</div><!--our_map end-->

    	<?php include 'include_File/footer.php';?>


</body>

</html>