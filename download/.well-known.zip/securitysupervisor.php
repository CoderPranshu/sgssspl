<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'include_File/head.php';?>
</head>

<body class="home layout2">

            	<?php include 'include_File/header.php';?>


	<div class="responsive-header">
		<div class="container">
			<div class="responsive_hd_logo">
				<a href="index.html" title="">
					<img src="images/logo2.png" alt="">
				</a>
			</div><!--responsive_hd_logo end-->
			<div class="responsive_header_navigations">
				<nav>
					<ul>
						<li><a href="index.html" title="">Home</a></li>
						<li><a href="about_page.html" title="">About us</a></li>
						<li><a class="active" href="services_page.html" title="">services</a>
							<ul>
								<li><a href="services_single.html" title="">Service Single</a></li>
							</ul>
						</li>
						<li><a href="price_page.html" title="">prices</a></li>
						<li><a href="gallery_page.html" title="">gallery</a></li>
						<li><a href="blog_posts_page.html" title="">blog</a>
							<ul>
								<li><a href="blog_single_post_page.html" title="">Blog Single</a></li>
							</ul>
						</li>
						<li><a href="faqs_page.html" title="">faqs</a></li>
						<li><a href="contact_page.html" title="">Contact us</a></li>
					</ul>
				</nav>
			</div><!--responsive_header_navigations end-->
			<a href="#" title="" class="menu_btn">
				<svg version="1.1" id="Layer_3" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					 viewBox="0 0 512 512"  xml:space="preserve">
				<g>
					<g>
						<path d="M491.318,235.318H20.682C9.26,235.318,0,244.577,0,256s9.26,20.682,20.682,20.682h470.636
							c11.423,0,20.682-9.259,20.682-20.682C512,244.578,502.741,235.318,491.318,235.318z"/>
					</g>
				</g>
				<g>
					<g>
						<path d="M491.318,78.439H20.682C9.26,78.439,0,87.699,0,99.121c0,11.422,9.26,20.682,20.682,20.682h470.636
							c11.423,0,20.682-9.26,20.682-20.682C512,87.699,502.741,78.439,491.318,78.439z"/>
					</g>
				</g>
				<g>
					<g>
						<path d="M491.318,392.197H20.682C9.26,392.197,0,401.456,0,412.879s9.26,20.682,20.682,20.682h470.636
							c11.423,0,20.682-9.259,20.682-20.682S502.741,392.197,491.318,392.197z"/>
					</g>
				</g>
				</svg>
					</a>
			<div class="clearfix"></div>
		</div>
	</div><!--responsive-header end-->

	<div class="responsive-menu">
		<a href="#" title="" class="close-mobile-menu"><img src="images/close.png" alt=""></a>
		<ul>
			<li><a href="index.html" title="">HOME</a></li>
			<li><a href="about_page.html" title="">About us</a></li>
			<li><a class="active" href="#" title="">Services</a>
				<ul>
					<li><a href="services_page.html" title="">Services</a></li>
					<li><a class="active" href="services_single.html" title="">Services Single</a></li>
				</ul>
			</li>
			<li><a href="price_page.html" title="">Prices</a></li>
			<li><a href="gallery_page.html" title="">Gallery</a></li>
			<li><a href="#" title="">blog</a>
				<ul>
					<li><a href="blog_posts_page.html" title="">Blog</a></li>
					<li><a href="blog_single_post_page.html" title="">Blog Single</a></li>
				</ul>
			</li>
			<li><a href="faqs_page.html" title="">faqs</a></li>
			<li><a href="contact_page.html" title="">contact us</a></li>
		</ul>
	</div><!--responsive-menu end-->

	<section class="pager-sec">
		<div class="container">
			<ul class="pager-info">
				<li> <a href="#" title="">Home</a></li>
				<li><span>Services</span></li>
			</ul><!--pager-info end-->
		</div>
	</section><!---pager-sec end-->


	<div class="page-content p-0">
		
	

	</div><!--page-content end-->

	<section class="newsletter-sec">
		<div  class="container">
			<ul class="nss_list">
				<li>
					<span>24/Hour</span> Emergency Service  
				</li>
				<li>
					<span>Free</span> Consultations  
				</li>
				<li>
					Newsletter Subscribe  
				</li>
			</ul><!--nss_list end-->
			<form class="newsletter_form">
				<input type="text" name="search" placeholder="Your e-mail...">
				<input type="submit" name="submit" value="OK">
			</form><!--newsletter_form  end-->
		</div>
	</section><!--newsletter-sec end-->

	<div class="our_map v1">
		<div class="mapouter">
			<iframe id="gmap_canvas4" src="https://maps.google.com/maps?q=university%20of%20san%20francisco&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
		</div>
	</div><!--our_map end-->

    	<?php include 'include_File/footer.php';?>


</body>

</html>