<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<title>SGSSPL</title>

<!-- Stylesheets -->
<link href="css/service.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon">
<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-datetimepicker.css" rel="stylesheet">
	<link rel="stylesheet" href="css/flaticon.css">
	<link href="css/animate.min.css" rel="stylesheet">
	<link href="css/slick.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/slick.css" rel="stylesheet">
	<link href="css/custom.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
	<!-- Icon Font-->
	<link href="css/style.css" rel="stylesheet">
</head>

<!-- page wrapper -->
<body >


    	<?php include 'include_File/header.php';?>



    <!-- page-title -->
    <section class="page-title" style="background-image: url(images/page-title.jpg);">
        <div class="container">
            <div class="content-box">
                <h1 class="title">Manned Guarding</h1>
                <ul class="bread-crumb">
                    <li><a href="index.html">Home</a></li>
                    <li>Services</li>
                </ul>
            </div>
        </div>
    </section>
    <!-- page-title end -->


    <!-- service-details -->
    <section class="service-details">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-12 col-sm-12 sidebar-side">
                    <div class="service-sidebar-content">
                        <div class="sidebar-categories wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <div class="sidebar-title"><h4>Our Services</h4></div>
                            <ul class="categories-list">
                                <li class="active"><a href="manned-guarding.html">Manned Guarding</a></li>
                                <li><a href="event-security.html">The Events Security</a></li>
                                <li><a href="security-installation.html">Security Installation</a></li>
                                <li><a href="canine-security.html">Canine Security</a></li>
                                <li><a href="mobile-security.html">Mobile Security</a></li>
                                <li><a href="alarm-monitoring.html">Alarm Monitoring</a></li>
                            </ul>
                        </div>
                        <div class="sidebar-call centred wow fadeInLeft" data-wow-delay="300ms" data-wow-duration="1500ms">
                            <div class="icon-box"><i class="flaticon-telephone"></i></div>
                            <div class="text">Got any Questions?<br>CALL US NOW</div>
                            <h3 class="phone"><a href="tel:0800-546-432">0800-546-432</a></h3>
                            <div class="email"><a href="mailto:support@example.com">support@example.com</a></div>
                            <div class="link"><a href="#">Get Free Estimate</a></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-md-12 col-sm-12 content-side">
                    <div class="service-details-content">
                        <div class="content-style-one">
                            <h2 class="title">Manned Guarding Division</h2>
                            <div class="text">
                                <p>On the other hand, we  being able to  being able to do what we like best. being able to do what we like best. being able to do what we like best. being able to do what we like best. being able to do what we like best. being able to do what we like best. being able to do what we like best. do what we like best. being able to do what we like best.  being able to do what we like best.  being able to do what we like best.  being able to do what we like best. denounce with  being able to do what we like best. righteous indignation and dislike men who are beguiled demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled.</p>
                            </div>
                            
                        </div>
                        <div class="content-style-two">
                            <div class="inner-content">
                                <div class="row">
                                    <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                                        <figure class="image-box"><img src="images/service-details2.jpg" alt></figure>
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 text-column">
                                        <div class="text">
                                            <p>Certain circumstances and owing to the claims of duty or the obligations of business will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always holds in these matters to this principle of selection: he rejects pleasures.</p>
                                            <p>Secure other greater pleasures, or else he endures pains to avoid worse pains. But I must explain you how all this mistaken idea of denouncing pleasue</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="text">Our Security Guards that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrink ing from toil and pain. These cases are perfectly simple and easy to distinguish. In free hour, when our power when nothing prevents our being able to do what we like best.</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- service-details end -->


	<?php include 'include_File/footer.php';?>


</body>

</html>
