	<footer id="footer-section" class="footer-section ow-background">
		<!-- container -->
		<div class="container">
			<div class="footer-heading">
				<h5>Have any questions or want a free estimate?</h5>
				<h3 style="color:white;">Call Now: +91-9891562274</h3>
			</div>
			<aside class="col-md-3 col-sm-3 widget widget-link">
				<h3>Our Services</h3>
				<ul>
					<li><a  href="service.php"><i class="fas fa-shield-alt"></i> Security Guard</a></li>
					<li><a  href="gunman.php"><i class="fas fa-shield-alt"></i> Gun Man</a></li>
					<li><a  href="surveillancerooms.php"><i class="fas fa-shield-alt"></i> Surveillance Rooms</a></li>
					<li><a  href="aso.php"><i class="fas fa-shield-alt"></i> ASO</a></li>
					<li><a  href="bouncers.php"><i class="fas fa-shield-alt"></i>Bouncers</a></li>
					<li><a  href="firesafetyexpert.php"><i class="fas fa-shield-alt"></i> Fire Safety Expert</a></li>
				</ul>
			</aside>
			
			<aside class="col-md-3 col-sm-3 widget widget-link">
				<h3>help</h3>
				<ul>
					<li><a title="Contact Us" href="#"><i class="fas fa-shield-alt"></i> Contact Us</a></li>
					<li><a title="Special Services" href="#"><i class="fas fa-shield-alt"></i> Special Services</a></li>
					<li><a title="Advice Tips" href="#"><i class="fas fa-shield-alt"></i> Advice & Tips</a></li>
					<li><a title="News Video" href="#"><i class="fas fa-shield-alt"></i> News & Video</a></li>
					<li><a title="Terms Condition" href="#"><i class="fas fa-shield-alt"></i> Terms & Condition</a></li>
					<li><a title="Site Map" href="#"><i class="fas fa-shield-alt"></i> Site Map</a></li>
				</ul>
			</aside>
			
			<aside class="col-md-2 col-sm-2 widget widget-link">
				<h3>page links</h3>
				<ul>
					<li><a title="Home" href="#"><i class="fas fa-shield-alt"></i> Home</a></li>
					<li><a title="About Us" href="#"><i class="fas fa-shield-alt"></i> About Us</a></li>
					<li><a title="Shop" href="#"><i class="fas fa-shield-alt"></i> Shop</a></li>
					<li><a title="Our Staffs" href="#"><i class="fas fa-shield-alt"></i> Our Staffs</a></li>
					<li><a title="Services" href="#"><i class="fas fa-shield-alt"></i> Services</a></li>
					<li><a title="Latest News" href="#"><i class="fas fa-shield-alt"></i> Latest News</a></li>
				</ul>
			</aside>
			
			<aside class="col-md-4 col-sm-4 widget widget-calculator">
				<h3>Our Contacts</h3>
				<ul>
										
										<li>
											<span><i style="color:blue" class="fa fa-clock-o"></i></span>
											<h4 style="color:white">Monday-Friday <br /> 8:00 am - 8:00 pm</h4>
										</li>
										<li>
											<span><i style="color:blue" class="fa fa-phone"></i></span>
											<h4 style="color:white">24/7 Emergency Service: +91-9891562274</h4> 
										</li>
									</ul>
			</aside>
			
			<!-- Footer Bottom -->
			<div class="footer-bottom">
				<p>Copyright © 2021 <a href="https://codesparrow.org/">Code Sparrow.</a> All Rights Reserved.</p>
			</div>
			<!-- Footer Bottom /- -->
			
		</div>
		<!-- container /- -->
	</footer><!-- Footer Section /- -->

