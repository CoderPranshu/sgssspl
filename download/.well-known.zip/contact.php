<head>
    	<?php include 'include_File/head.php';?>
    	<link href="iconfont/style.css" rel="stylesheet">
</head>
<body>
	<?php include 'include_File/header.php';?>
<section class="map-full">
	<div style="width: 100%"><iframe width="100%" height="600" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=near%20palam%20metro%20station+(sgsspl)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
		<div class="mp_contact_info">
			<div class="container">
				<div class="mp_contact_info_details">
					<div class="row">
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 full_wdth">
							<div class="cpt_info">
								<span class="cpt_icon"><i class="fa fa-map-marker"></i></span>
								<div class="cppt">
									<span>Address:</span>  	
									<h3>Near Palam Metro Station New Delhi</h3>
								</div>
							</div><!--cpt_info end-->
						</div>
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 full_wdth">
							<div class="cpt_info">
								<span class="cpt_icon"><i class="fa fa-envelope"></i></span>
								<div class="cppt">
									<span>E-mail:</span>  	
									<h3>info@sgsspl.com</h3>
								</div>
							</div><!--cpt_info end-->
						</div>
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 full_wdth">
							<div class="cpt_info">
								<span class="cpt_icon"><i class="fa fa-phone"></i></span>
								<div class="cppt">
									<span>Phone:</span>  	
									<h3>+91-95403 28830<br>
									+91-98915 62274
									</h3>
								</div>
							</div><!--cpt_info end-->
						</div>
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 full_wdth">
							<div class="cpt_info">
								<span class="cpt_icon"><i class="fa fa-clock-o"></i></span>
								<div class="cppt">
									<span>Mon-Sat:</span>  	
									<h3>8:00 AM - 8:00 PM</h3>
								</div>
							</div><!--cpt_info end-->
						</div>
					</div>
				</div><!--mp_contact_info_details end-->
			</div>
		</div><!--mp_contact_info end-->
	</section><!--map-full end-->


	<div class="page-content p-0">
		<div class="container" style="padding-top:80px;padding-bottom:80px;">
			<section class="getin_touch block">
				<div class="row">
					<div class="col-lg-4 col-md-4">
						<div class="gettouch_text">
							<h3 class="sc-title">Contact <span>Us</span></h3>
							<p>SUPER GLOBAL SEFTY SECURITY SERVICES PVT. LTD. is a leading security and housekeeping company capable of meeting all security needs of its client, to their entire satisfaction. </p>
							<h4>Follow us:</h4>
							<ul class="social_lnks">
								<li><a href="#" title=""><i class="fa fa-facebook"></i></a></li>
								<li><a href="#" title=""><i class="fa fa-twitter"></i></a></li>
								<li><a href="#" title=""><i class="fa fa-instagram"></i></a></li>
							</ul>
						</div><!--gettouch_text end-->
					</div>
					<div class="col-lg-8 col-md-8">
						<div class="question_sec">
							<form id="contactform" name="contactform" method="post" novalidate>
								<div id="success">
									<p>Your message was sent successfully!</p>
								</div>
								<div id="error">
									<p>Something went wrong, try refreshing and submitting the form again.</p>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<div class="input_field">
											<input type="text" name="name" placeholder="Your name">
										</div><!--input_field end-->
									</div>
									<div class="col-lg-6">
										<div class="input_field">
											<input type="number" name="phone" placeholder="Phone">
										</div><!--input_field end-->
									</div>
									<div class="col-lg-6">
										<div class="input_field">
											<input type="email" name="email" placeholder="Your e-mail">
										</div><!--input_field end-->
									</div>
									<div class="col-lg-12">
										<div class="input_field">
											<textarea name="message" placeholder="Your question"></textarea>
										</div><!--input_field end-->
									</div>
									<div class="col-lg-12">
										<div class="submit_btn">
											<input type="submit" id="submit" name="submit" value="Send Message">
										</div><!--submit_btn end-->
									</div>
								</div>
							</form>
						</div><!--question-sec end-->
					</div>
				</div>
			</section><!--getin_touch end-->
		</div>	
	</div><!--page-content end-->



	<div class="our_map v1">
		<div class="mapouter">
			<iframe id="gmap_canvas4" src="https://maps.google.com/maps?q=university%20of%20san%20francisco&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
		</div>
	</div><!--our_map end-->
	<?php include 'include_File/footer.php';?>
</body>
<script src="js/jquery.js"></script>
	<script src="js/plugins/bootstrap.min.js"></script>
	<script src="js/plugins/moment.min.js"></script>
	<script src="js/plugins/bootstrap-datetimepicker.min.js"></script>
	<script src="js/plugins/jquery.form.js"></script>
	<script src="js/plugins/jquery.validate.min.js"></script>
	<script src="js/plugins/slick.min.js"></script>
	<script src="js/plugins/custom-tabs.js"></script>
	<script src="js/forms.js"></script>
	<script src="js/scripts.js"></script>