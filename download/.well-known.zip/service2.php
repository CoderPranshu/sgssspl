<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'include_File/head.php';?>
</head>

<body class="home layout2">

            	<?php include 'include_File/header.php';?>


	<div class="responsive-header">
		<div class="container">
			<div class="responsive_hd_logo">
				<a href="index.html" title="">
					<img src="images/logo2.png" alt="">
				</a>
			</div><!--responsive_hd_logo end-->
			<div class="responsive_header_navigations">
				<nav>
					<ul>
						<li><a href="index.html" title="">Home</a></li>
						<li><a href="about_page.html" title="">About us</a></li>
						<li><a class="active" href="services_page.html" title="">services</a>
							<ul>
								<li><a href="services_single.html" title="">Service Single</a></li>
							</ul>
						</li>
						<li><a href="price_page.html" title="">prices</a></li>
						<li><a href="gallery_page.html" title="">gallery</a></li>
						<li><a href="blog_posts_page.html" title="">blog</a>
							<ul>
								<li><a href="blog_single_post_page.html" title="">Blog Single</a></li>
							</ul>
						</li>
						<li><a href="faqs_page.html" title="">faqs</a></li>
						<li><a href="contact_page.html" title="">Contact us</a></li>
					</ul>
				</nav>
			</div><!--responsive_header_navigations end-->
			<a href="#" title="" class="menu_btn">
				<svg version="1.1" id="Layer_3" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					 viewBox="0 0 512 512"  xml:space="preserve">
				<g>
					<g>
						<path d="M491.318,235.318H20.682C9.26,235.318,0,244.577,0,256s9.26,20.682,20.682,20.682h470.636
							c11.423,0,20.682-9.259,20.682-20.682C512,244.578,502.741,235.318,491.318,235.318z"/>
					</g>
				</g>
				<g>
					<g>
						<path d="M491.318,78.439H20.682C9.26,78.439,0,87.699,0,99.121c0,11.422,9.26,20.682,20.682,20.682h470.636
							c11.423,0,20.682-9.26,20.682-20.682C512,87.699,502.741,78.439,491.318,78.439z"/>
					</g>
				</g>
				<g>
					<g>
						<path d="M491.318,392.197H20.682C9.26,392.197,0,401.456,0,412.879s9.26,20.682,20.682,20.682h470.636
							c11.423,0,20.682-9.259,20.682-20.682S502.741,392.197,491.318,392.197z"/>
					</g>
				</g>
				</svg>
					</a>
			<div class="clearfix"></div>
		</div>
	</div><!--responsive-header end-->

	<div class="responsive-menu">
		<a href="#" title="" class="close-mobile-menu"><img src="images/close.png" alt=""></a>
		<ul>
			<li><a href="index.html" title="">HOME</a></li>
			<li><a href="about_page.html" title="">About us</a></li>
			<li><a class="active" href="#" title="">Services</a>
				<ul>
					<li><a href="services_page.html" title="">Services</a></li>
					<li><a class="active" href="services_single.html" title="">Services Single</a></li>
				</ul>
			</li>
			<li><a href="price_page.html" title="">Prices</a></li>
			<li><a href="gallery_page.html" title="">Gallery</a></li>
			<li><a href="#" title="">blog</a>
				<ul>
					<li><a href="blog_posts_page.html" title="">Blog</a></li>
					<li><a href="blog_single_post_page.html" title="">Blog Single</a></li>
				</ul>
			</li>
			<li><a href="faqs_page.html" title="">faqs</a></li>
			<li><a href="contact_page.html" title="">contact us</a></li>
		</ul>
	</div><!--responsive-menu end-->

	<section class="pager-sec">
		<div class="container">
			<ul class="pager-info">
				<li> <a href="#" title="">Home</a></li>
				<li><span>Services</span></li>
			</ul><!--pager-info end-->
		</div>
	</section><!---pager-sec end-->


	<div class="page-content p-0">
		
		<section class="block tp-100">
			<div class="container">
				<div class="service_single_page">
					<div class="row">
						<div class="col-lg-9 col-md-9 pull-right">
							<div class="service-single-details">
								<div class="service-single">
									<h2>Air Conditioning</h2>
									<img src="http://websmirno.site/kax/heatingandcooling/images/resources/service-img.jpg" alt="">
									<h3>High Efficient Ac Installation, A/c Installation & Air Conditioning Installation</h3>
									<p>Central air conditioning allows you to enjoy the perfect temperature in any room of your house. Bedrooms can be kept refreshingly cool even on the stickiest summer nights. You’ll benefit from ideal sleeping conditions, complete humidity control, and a fresher, cleaner home. Through effective, air-purifying filtration systems, cooling units also reduce bacteria, dust, house mites, mold, pet dander and pollen, proving extremely beneficial for those who suffer from allergies and respiratory problems. </p>
									<p> When you’re ready to experience your summer in a whole new way, call Heating & Cooling for air conditioning installation, and we’ll exceed your expectations.</p>
									<h3>Expert AC Replacement</h3>
									<p>At Heating & Cooling we are committed to doing the job right. As a Factory Authorized Dealer, our technicians are NATE-certified professionals who have completed a demanding set of core and specialty exams to ensure their technical competency. They also continue training specific to Carrier technology and products. We are fully bonded and insured, offer free in-home estimates and convenient financing options.  As family owned and operated business since 2010, we’ve served the comfort needs of Pittsburgh and the surrounding areas with a dedication to providing the best prices for the very best service.</p>
									<p> When it comes to managing indoor humidity, the two-stage compressor makes a significant comfort difference, allowing the system to function mostly in low-stage, where you achieve the highest efficiency.  A filter drier system protects against moisture and contaminants while compressor sound blanket keeps operational noise down to 65 decibels.</p>
									<h3>Top Quality Air Conditioning Installation</h3>
									<p>By installing an air conditioning system that has met the standards set by the Environmental Protection Agency, you stand to save 30% on cooling bills each year. </p>
									<p>The factory-trained technicians from Heating & Cooling have the experience, product knowledge and commitment to design a system to perfectly match your expectations for efficiency, performance and budget. Through skilled and meticulous installation, our team will get the most out of your energy dollar, allowing you to maintain luxurious indoor temperatures without suffering the consequences of high utility bills.  We not only take pride in completing your project quickly, neatly and perfectly, we’re available for seasonal maintenance to keep your system operating at peak capacity. </p>
								</div><!--service-single end-->
								<div class="service-svv">
									<div class="svv-img">
										<img src="http://websmirno.site/kax/heatingandcooling/images/resources/vc.png" alt="">
									</div>
									<div class="svv-info">
										<h3>Peace of mind for you and your family.</h3>
										<p>Cooling & Heating has been repairing AC systems for more than 10 years. We want you to be cool and comfortable, and we’ll guarantee any repairs we make through a one-year warranty.</p>
									</div><!--svv-info end-->
								</div><!--service-svv end-->
							</div>
						</div>
						<div class="col-lg-3 col-md-3 ful_wd pull-left">
							<div class="side_bar">
								<div class="dvis">
									<ul style="padding-top: 80px;" class="tabs_list">
										
										<li class="active heating" data-tab="hea_ting">
										   
                                            <i class="fas fa-shield-alt" style=" font-size: 3em; "></i>
											<span class="svs">Heating Services</span>
										</li>
								        	<li class="active heating" data-tab="hea_ting">
											<span class="tc_icon">
												<svg version="1.1" id="Capa_6" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
													 width="45.16px" height="45.16px" viewBox="0 0 45.16 45.16" xml:space="preserve"
													>
												<g>
													<g>
														<path d="M22.58,11.269c-6.237,0-11.311,5.075-11.311,11.312s5.074,11.312,11.311,11.312c6.236,0,11.311-5.074,11.311-11.312
															S28.816,11.269,22.58,11.269z"/>
														<g>
															<g>
																<path d="M22.58,7.944c-1.219,0-2.207-0.988-2.207-2.206V2.207C20.373,0.988,21.361,0,22.58,0c1.219,0,2.207,0.988,2.207,2.207
																	v3.531C24.787,6.956,23.798,7.944,22.58,7.944z"/>
															</g>
															<g>
																<path d="M22.58,37.215c-1.219,0-2.207,0.988-2.207,2.207v3.53c0,1.22,0.988,2.208,2.207,2.208c1.219,0,2.207-0.988,2.207-2.208
																	v-3.53C24.787,38.203,23.798,37.215,22.58,37.215z"/>
															</g>
															<g>
																<path d="M32.928,12.231c-0.861-0.862-0.861-2.259,0-3.121l2.497-2.497c0.861-0.861,2.259-0.861,3.121,0
																	c0.862,0.862,0.862,2.26,0,3.121l-2.497,2.497C35.188,13.093,33.791,13.093,32.928,12.231z"/>
															</g>
															<g>
																<path d="M12.231,32.93c-0.862-0.863-2.259-0.863-3.121,0l-2.497,2.496c-0.861,0.861-0.862,2.26,0,3.121
																	c0.862,0.861,2.26,0.861,3.121,0l2.497-2.498C13.093,35.188,13.093,33.79,12.231,32.93z"/>
															</g>
															<g>
																<path d="M37.215,22.58c0-1.219,0.988-2.207,2.207-2.207h3.531c1.219,0,2.207,0.988,2.207,2.207c0,1.219-0.988,2.206-2.207,2.206
																	h-3.531C38.203,24.786,37.215,23.799,37.215,22.58z"/>
															</g>
															<g>
																<path d="M7.944,22.58c0-1.219-0.988-2.207-2.207-2.207h-3.53C0.988,20.373,0,21.361,0,22.58c0,1.219,0.988,2.206,2.207,2.206
																	h3.531C6.956,24.786,7.944,23.799,7.944,22.58z"/>
															</g>
															<g>
																<path d="M32.928,32.93c0.862-0.861,2.26-0.861,3.121,0l2.497,2.497c0.862,0.86,0.862,2.259,0,3.12s-2.259,0.861-3.121,0
																	l-2.497-2.497C32.066,35.188,32.066,33.791,32.928,32.93z"/>
															</g>
															<g>
																<path d="M12.231,12.231c0.862-0.862,0.862-2.259,0-3.121L9.734,6.614c-0.862-0.862-2.259-0.862-3.121,0
																	c-0.862,0.861-0.862,2.259,0,3.12l2.497,2.497C9.972,13.094,11.369,13.094,12.231,12.231z"/>
															</g>
														</g>
													</g>
												</g>
												</svg>
											</span>
											<span class="svs">Heating Services1</span>
										</li>
									<li class="active heating" data-tab="hea_ting">
											<span class="tc_icon">
												<svg version="1.1" id="Capa_6" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
													 width="45.16px" height="45.16px" viewBox="0 0 45.16 45.16" xml:space="preserve"
													>
												<g>
													<g>
														<path d="M22.58,11.269c-6.237,0-11.311,5.075-11.311,11.312s5.074,11.312,11.311,11.312c6.236,0,11.311-5.074,11.311-11.312
															S28.816,11.269,22.58,11.269z"/>
														<g>
															<g>
																<path d="M22.58,7.944c-1.219,0-2.207-0.988-2.207-2.206V2.207C20.373,0.988,21.361,0,22.58,0c1.219,0,2.207,0.988,2.207,2.207
																	v3.531C24.787,6.956,23.798,7.944,22.58,7.944z"/>
															</g>
															<g>
																<path d="M22.58,37.215c-1.219,0-2.207,0.988-2.207,2.207v3.53c0,1.22,0.988,2.208,2.207,2.208c1.219,0,2.207-0.988,2.207-2.208
																	v-3.53C24.787,38.203,23.798,37.215,22.58,37.215z"/>
															</g>
															<g>
																<path d="M32.928,12.231c-0.861-0.862-0.861-2.259,0-3.121l2.497-2.497c0.861-0.861,2.259-0.861,3.121,0
																	c0.862,0.862,0.862,2.26,0,3.121l-2.497,2.497C35.188,13.093,33.791,13.093,32.928,12.231z"/>
															</g>
															<g>
																<path d="M12.231,32.93c-0.862-0.863-2.259-0.863-3.121,0l-2.497,2.496c-0.861,0.861-0.862,2.26,0,3.121
																	c0.862,0.861,2.26,0.861,3.121,0l2.497-2.498C13.093,35.188,13.093,33.79,12.231,32.93z"/>
															</g>
															<g>
																<path d="M37.215,22.58c0-1.219,0.988-2.207,2.207-2.207h3.531c1.219,0,2.207,0.988,2.207,2.207c0,1.219-0.988,2.206-2.207,2.206
																	h-3.531C38.203,24.786,37.215,23.799,37.215,22.58z"/>
															</g>
															<g>
																<path d="M7.944,22.58c0-1.219-0.988-2.207-2.207-2.207h-3.53C0.988,20.373,0,21.361,0,22.58c0,1.219,0.988,2.206,2.207,2.206
																	h3.531C6.956,24.786,7.944,23.799,7.944,22.58z"/>
															</g>
															<g>
																<path d="M32.928,32.93c0.862-0.861,2.26-0.861,3.121,0l2.497,2.497c0.862,0.86,0.862,2.259,0,3.12s-2.259,0.861-3.121,0
																	l-2.497-2.497C32.066,35.188,32.066,33.791,32.928,32.93z"/>
															</g>
															<g>
																<path d="M12.231,12.231c0.862-0.862,0.862-2.259,0-3.121L9.734,6.614c-0.862-0.862-2.259-0.862-3.121,0
																	c-0.862,0.861-0.862,2.259,0,3.12l2.497,2.497C9.972,13.094,11.369,13.094,12.231,12.231z"/>
															</g>
														</g>
													</g>
												</g>
												</svg>
											</span>
											<span class="svs">Heating Services</span>
										</li>
									<li class="active heating" data-tab="hea_ting">
											<span class="tc_icon">
												<svg version="1.1" id="Capa_6" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
													 width="45.16px" height="45.16px" viewBox="0 0 45.16 45.16" xml:space="preserve"
													>
												<g>
													<g>
														<path d="M22.58,11.269c-6.237,0-11.311,5.075-11.311,11.312s5.074,11.312,11.311,11.312c6.236,0,11.311-5.074,11.311-11.312
															S28.816,11.269,22.58,11.269z"/>
														<g>
															<g>
																<path d="M22.58,7.944c-1.219,0-2.207-0.988-2.207-2.206V2.207C20.373,0.988,21.361,0,22.58,0c1.219,0,2.207,0.988,2.207,2.207
																	v3.531C24.787,6.956,23.798,7.944,22.58,7.944z"/>
															</g>
															<g>
																<path d="M22.58,37.215c-1.219,0-2.207,0.988-2.207,2.207v3.53c0,1.22,0.988,2.208,2.207,2.208c1.219,0,2.207-0.988,2.207-2.208
																	v-3.53C24.787,38.203,23.798,37.215,22.58,37.215z"/>
															</g>
															<g>
																<path d="M32.928,12.231c-0.861-0.862-0.861-2.259,0-3.121l2.497-2.497c0.861-0.861,2.259-0.861,3.121,0
																	c0.862,0.862,0.862,2.26,0,3.121l-2.497,2.497C35.188,13.093,33.791,13.093,32.928,12.231z"/>
															</g>
															<g>
																<path d="M12.231,32.93c-0.862-0.863-2.259-0.863-3.121,0l-2.497,2.496c-0.861,0.861-0.862,2.26,0,3.121
																	c0.862,0.861,2.26,0.861,3.121,0l2.497-2.498C13.093,35.188,13.093,33.79,12.231,32.93z"/>
															</g>
															<g>
																<path d="M37.215,22.58c0-1.219,0.988-2.207,2.207-2.207h3.531c1.219,0,2.207,0.988,2.207,2.207c0,1.219-0.988,2.206-2.207,2.206
																	h-3.531C38.203,24.786,37.215,23.799,37.215,22.58z"/>
															</g>
															<g>
																<path d="M7.944,22.58c0-1.219-0.988-2.207-2.207-2.207h-3.53C0.988,20.373,0,21.361,0,22.58c0,1.219,0.988,2.206,2.207,2.206
																	h3.531C6.956,24.786,7.944,23.799,7.944,22.58z"/>
															</g>
															<g>
																<path d="M32.928,32.93c0.862-0.861,2.26-0.861,3.121,0l2.497,2.497c0.862,0.86,0.862,2.259,0,3.12s-2.259,0.861-3.121,0
																	l-2.497-2.497C32.066,35.188,32.066,33.791,32.928,32.93z"/>
															</g>
															<g>
																<path d="M12.231,12.231c0.862-0.862,0.862-2.259,0-3.121L9.734,6.614c-0.862-0.862-2.259-0.862-3.121,0
																	c-0.862,0.861-0.862,2.259,0,3.12l2.497,2.497C9.972,13.094,11.369,13.094,12.231,12.231z"/>
															</g>
														</g>
													</g>
												</g>
												</svg>
											</span>
											<span class="svs">Heating Services</span>
										</li>
									<li class="active heating" data-tab="hea_ting">
											<span class="tc_icon">
												<svg version="1.1" id="Capa_6" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
													 width="45.16px" height="45.16px" viewBox="0 0 45.16 45.16" xml:space="preserve"
													>
												<g>
													<g>
														<path d="M22.58,11.269c-6.237,0-11.311,5.075-11.311,11.312s5.074,11.312,11.311,11.312c6.236,0,11.311-5.074,11.311-11.312
															S28.816,11.269,22.58,11.269z"/>
														<g>
															<g>
																<path d="M22.58,7.944c-1.219,0-2.207-0.988-2.207-2.206V2.207C20.373,0.988,21.361,0,22.58,0c1.219,0,2.207,0.988,2.207,2.207
																	v3.531C24.787,6.956,23.798,7.944,22.58,7.944z"/>
															</g>
															<g>
																<path d="M22.58,37.215c-1.219,0-2.207,0.988-2.207,2.207v3.53c0,1.22,0.988,2.208,2.207,2.208c1.219,0,2.207-0.988,2.207-2.208
																	v-3.53C24.787,38.203,23.798,37.215,22.58,37.215z"/>
															</g>
															<g>
																<path d="M32.928,12.231c-0.861-0.862-0.861-2.259,0-3.121l2.497-2.497c0.861-0.861,2.259-0.861,3.121,0
																	c0.862,0.862,0.862,2.26,0,3.121l-2.497,2.497C35.188,13.093,33.791,13.093,32.928,12.231z"/>
															</g>
															<g>
																<path d="M12.231,32.93c-0.862-0.863-2.259-0.863-3.121,0l-2.497,2.496c-0.861,0.861-0.862,2.26,0,3.121
																	c0.862,0.861,2.26,0.861,3.121,0l2.497-2.498C13.093,35.188,13.093,33.79,12.231,32.93z"/>
															</g>
															<g>
																<path d="M37.215,22.58c0-1.219,0.988-2.207,2.207-2.207h3.531c1.219,0,2.207,0.988,2.207,2.207c0,1.219-0.988,2.206-2.207,2.206
																	h-3.531C38.203,24.786,37.215,23.799,37.215,22.58z"/>
															</g>
															<g>
																<path d="M7.944,22.58c0-1.219-0.988-2.207-2.207-2.207h-3.53C0.988,20.373,0,21.361,0,22.58c0,1.219,0.988,2.206,2.207,2.206
																	h3.531C6.956,24.786,7.944,23.799,7.944,22.58z"/>
															</g>
															<g>
																<path d="M32.928,32.93c0.862-0.861,2.26-0.861,3.121,0l2.497,2.497c0.862,0.86,0.862,2.259,0,3.12s-2.259,0.861-3.121,0
																	l-2.497-2.497C32.066,35.188,32.066,33.791,32.928,32.93z"/>
															</g>
															<g>
																<path d="M12.231,12.231c0.862-0.862,0.862-2.259,0-3.121L9.734,6.614c-0.862-0.862-2.259-0.862-3.121,0
																	c-0.862,0.861-0.862,2.259,0,3.12l2.497,2.497C9.972,13.094,11.369,13.094,12.231,12.231z"/>
															</g>
														</g>
													</g>
												</g>
												</svg>
											</span>
											<span class="svs">Heating Services</span>
										</li>
									<li class="active heating" data-tab="hea_ting">
											<span class="tc_icon">
												<svg version="1.1" id="Capa_6" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
													 width="45.16px" height="45.16px" viewBox="0 0 45.16 45.16" xml:space="preserve"
													>
												<g>
													<g>
														<path d="M22.58,11.269c-6.237,0-11.311,5.075-11.311,11.312s5.074,11.312,11.311,11.312c6.236,0,11.311-5.074,11.311-11.312
															S28.816,11.269,22.58,11.269z"/>
														<g>
															<g>
																<path d="M22.58,7.944c-1.219,0-2.207-0.988-2.207-2.206V2.207C20.373,0.988,21.361,0,22.58,0c1.219,0,2.207,0.988,2.207,2.207
																	v3.531C24.787,6.956,23.798,7.944,22.58,7.944z"/>
															</g>
															<g>
																<path d="M22.58,37.215c-1.219,0-2.207,0.988-2.207,2.207v3.53c0,1.22,0.988,2.208,2.207,2.208c1.219,0,2.207-0.988,2.207-2.208
																	v-3.53C24.787,38.203,23.798,37.215,22.58,37.215z"/>
															</g>
															<g>
																<path d="M32.928,12.231c-0.861-0.862-0.861-2.259,0-3.121l2.497-2.497c0.861-0.861,2.259-0.861,3.121,0
																	c0.862,0.862,0.862,2.26,0,3.121l-2.497,2.497C35.188,13.093,33.791,13.093,32.928,12.231z"/>
															</g>
															<g>
																<path d="M12.231,32.93c-0.862-0.863-2.259-0.863-3.121,0l-2.497,2.496c-0.861,0.861-0.862,2.26,0,3.121
																	c0.862,0.861,2.26,0.861,3.121,0l2.497-2.498C13.093,35.188,13.093,33.79,12.231,32.93z"/>
															</g>
															<g>
																<path d="M37.215,22.58c0-1.219,0.988-2.207,2.207-2.207h3.531c1.219,0,2.207,0.988,2.207,2.207c0,1.219-0.988,2.206-2.207,2.206
																	h-3.531C38.203,24.786,37.215,23.799,37.215,22.58z"/>
															</g>
															<g>
																<path d="M7.944,22.58c0-1.219-0.988-2.207-2.207-2.207h-3.53C0.988,20.373,0,21.361,0,22.58c0,1.219,0.988,2.206,2.207,2.206
																	h3.531C6.956,24.786,7.944,23.799,7.944,22.58z"/>
															</g>
															<g>
																<path d="M32.928,32.93c0.862-0.861,2.26-0.861,3.121,0l2.497,2.497c0.862,0.86,0.862,2.259,0,3.12s-2.259,0.861-3.121,0
																	l-2.497-2.497C32.066,35.188,32.066,33.791,32.928,32.93z"/>
															</g>
															<g>
																<path d="M12.231,12.231c0.862-0.862,0.862-2.259,0-3.121L9.734,6.614c-0.862-0.862-2.259-0.862-3.121,0
																	c-0.862,0.861-0.862,2.259,0,3.12l2.497,2.497C9.972,13.094,11.369,13.094,12.231,12.231z"/>
															</g>
														</g>
													</g>
												</g>
												</svg>
											</span>
											<span class="svs">Heating Services</span>
										</li>
									<li class="active heating" data-tab="hea_ting">
											<span class="tc_icon">
												<svg version="1.1" id="Capa_6" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
													 width="45.16px" height="45.16px" viewBox="0 0 45.16 45.16" xml:space="preserve"
													>
												<g>
													<g>
														<path d="M22.58,11.269c-6.237,0-11.311,5.075-11.311,11.312s5.074,11.312,11.311,11.312c6.236,0,11.311-5.074,11.311-11.312
															S28.816,11.269,22.58,11.269z"/>
														<g>
															<g>
																<path d="M22.58,7.944c-1.219,0-2.207-0.988-2.207-2.206V2.207C20.373,0.988,21.361,0,22.58,0c1.219,0,2.207,0.988,2.207,2.207
																	v3.531C24.787,6.956,23.798,7.944,22.58,7.944z"/>
															</g>
															<g>
																<path d="M22.58,37.215c-1.219,0-2.207,0.988-2.207,2.207v3.53c0,1.22,0.988,2.208,2.207,2.208c1.219,0,2.207-0.988,2.207-2.208
																	v-3.53C24.787,38.203,23.798,37.215,22.58,37.215z"/>
															</g>
															<g>
																<path d="M32.928,12.231c-0.861-0.862-0.861-2.259,0-3.121l2.497-2.497c0.861-0.861,2.259-0.861,3.121,0
																	c0.862,0.862,0.862,2.26,0,3.121l-2.497,2.497C35.188,13.093,33.791,13.093,32.928,12.231z"/>
															</g>
															<g>
																<path d="M12.231,32.93c-0.862-0.863-2.259-0.863-3.121,0l-2.497,2.496c-0.861,0.861-0.862,2.26,0,3.121
																	c0.862,0.861,2.26,0.861,3.121,0l2.497-2.498C13.093,35.188,13.093,33.79,12.231,32.93z"/>
															</g>
															<g>
																<path d="M37.215,22.58c0-1.219,0.988-2.207,2.207-2.207h3.531c1.219,0,2.207,0.988,2.207,2.207c0,1.219-0.988,2.206-2.207,2.206
																	h-3.531C38.203,24.786,37.215,23.799,37.215,22.58z"/>
															</g>
															<g>
																<path d="M7.944,22.58c0-1.219-0.988-2.207-2.207-2.207h-3.53C0.988,20.373,0,21.361,0,22.58c0,1.219,0.988,2.206,2.207,2.206
																	h3.531C6.956,24.786,7.944,23.799,7.944,22.58z"/>
															</g>
															<g>
																<path d="M32.928,32.93c0.862-0.861,2.26-0.861,3.121,0l2.497,2.497c0.862,0.86,0.862,2.259,0,3.12s-2.259,0.861-3.121,0
																	l-2.497-2.497C32.066,35.188,32.066,33.791,32.928,32.93z"/>
															</g>
															<g>
																<path d="M12.231,12.231c0.862-0.862,0.862-2.259,0-3.121L9.734,6.614c-0.862-0.862-2.259-0.862-3.121,0
																	c-0.862,0.861-0.862,2.259,0,3.12l2.497,2.497C9.972,13.094,11.369,13.094,12.231,12.231z"/>
															</g>
														</g>
													</g>
												</g>
												</svg>
											</span>
											<span class="svs">Heating Services</span>
										</li>
									<li class="active heating" data-tab="hea_ting">
											<span class="tc_icon">
												<svg version="1.1" id="Capa_6" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
													 width="45.16px" height="45.16px" viewBox="0 0 45.16 45.16" xml:space="preserve"
													>
												<g>
													<g>
														<path d="M22.58,11.269c-6.237,0-11.311,5.075-11.311,11.312s5.074,11.312,11.311,11.312c6.236,0,11.311-5.074,11.311-11.312
															S28.816,11.269,22.58,11.269z"/>
														<g>
															<g>
																<path d="M22.58,7.944c-1.219,0-2.207-0.988-2.207-2.206V2.207C20.373,0.988,21.361,0,22.58,0c1.219,0,2.207,0.988,2.207,2.207
																	v3.531C24.787,6.956,23.798,7.944,22.58,7.944z"/>
															</g>
															<g>
																<path d="M22.58,37.215c-1.219,0-2.207,0.988-2.207,2.207v3.53c0,1.22,0.988,2.208,2.207,2.208c1.219,0,2.207-0.988,2.207-2.208
																	v-3.53C24.787,38.203,23.798,37.215,22.58,37.215z"/>
															</g>
															<g>
																<path d="M32.928,12.231c-0.861-0.862-0.861-2.259,0-3.121l2.497-2.497c0.861-0.861,2.259-0.861,3.121,0
																	c0.862,0.862,0.862,2.26,0,3.121l-2.497,2.497C35.188,13.093,33.791,13.093,32.928,12.231z"/>
															</g>
															<g>
																<path d="M12.231,32.93c-0.862-0.863-2.259-0.863-3.121,0l-2.497,2.496c-0.861,0.861-0.862,2.26,0,3.121
																	c0.862,0.861,2.26,0.861,3.121,0l2.497-2.498C13.093,35.188,13.093,33.79,12.231,32.93z"/>
															</g>
															<g>
																<path d="M37.215,22.58c0-1.219,0.988-2.207,2.207-2.207h3.531c1.219,0,2.207,0.988,2.207,2.207c0,1.219-0.988,2.206-2.207,2.206
																	h-3.531C38.203,24.786,37.215,23.799,37.215,22.58z"/>
															</g>
															<g>
																<path d="M7.944,22.58c0-1.219-0.988-2.207-2.207-2.207h-3.53C0.988,20.373,0,21.361,0,22.58c0,1.219,0.988,2.206,2.207,2.206
																	h3.531C6.956,24.786,7.944,23.799,7.944,22.58z"/>
															</g>
															<g>
																<path d="M32.928,32.93c0.862-0.861,2.26-0.861,3.121,0l2.497,2.497c0.862,0.86,0.862,2.259,0,3.12s-2.259,0.861-3.121,0
																	l-2.497-2.497C32.066,35.188,32.066,33.791,32.928,32.93z"/>
															</g>
															<g>
																<path d="M12.231,12.231c0.862-0.862,0.862-2.259,0-3.121L9.734,6.614c-0.862-0.862-2.259-0.862-3.121,0
																	c-0.862,0.861-0.862,2.259,0,3.12l2.497,2.497C9.972,13.094,11.369,13.094,12.231,12.231z"/>
															</g>
														</g>
													</g>
												</g>
												</svg>
											</span>
											<span class="svs">Heating Services</span>
										</li>
								
									</ul><!--tabs_list end-->
								
								</div><!--dvis end-->
								<div class="contact_wd">
									<h3>Our Contacts</h3>
									<ul>
										<li>
											<span><i class="fa fa-map-marker"></i></span>
											<h4>1531 Moonlight Drive, Maple Shade, NJ</h4>
										</li>
										<li>
											<span><i class="fa fa-clock-o"></i></span>
											<h4>Monday-Friday <br /> 8:00 am - 8:00 pm</h4>
										</li>
										<li>
											<span><i class="fa fa-phone"></i></span>
											<h4>24/7 Emergency Service: 609-123-4567</h4> 
										</li>
									</ul>
								</div><!--contact_wd end-->
								<div class="ht_form">
									<h3>Ask Question</h3>
									<form id="contactform" name="contactform" method="post" novalidate>
										<div id="success">
											<p>Your message was sent successfully!</p>
										</div>
										<div id="error">
											<p>Something went wrong, try refreshing and submitting the form again.</p>
										</div>
										<div class="input_field">
											<input type="text" name="name" placeholder="Your name">
										</div>
										<div class="input_field">
											<input type="text" name="email" placeholder="Your e-mail">
										</div>
										<div class="input_field">
											<textarea name="message" placeholder="Your question"></textarea>
										</div>
										<div class="submit_btn">
											<input type="submit" id="submit" name="submit" value="Ask Question">
										</div>
									</form>
								</div><!--ht_form end-->
							</div><!--side_bar end-->
						</div>
					</div>
				</div><!--service_single_page end-->
			</div>
		</section>

	</div><!--page-content end-->

	<section class="newsletter-sec">
		<div  class="container">
			<ul class="nss_list">
				<li>
					<span>24/Hour</span> Emergency Service  
				</li>
				<li>
					<span>Free</span> Consultations  
				</li>
				<li>
					Newsletter Subscribe  
				</li>
			</ul><!--nss_list end-->
			<form class="newsletter_form">
				<input type="text" name="search" placeholder="Your e-mail...">
				<input type="submit" name="submit" value="OK">
			</form><!--newsletter_form  end-->
		</div>
	</section><!--newsletter-sec end-->

	<div class="our_map v1">
		<div class="mapouter">
			<iframe id="gmap_canvas4" src="https://maps.google.com/maps?q=university%20of%20san%20francisco&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
		</div>
	</div><!--our_map end-->

    	<?php include 'include_File/footer.php';?>


</body>

</html>