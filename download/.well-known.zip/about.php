<!doctype html>
<html lang="zxx">

<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="assets/css/bootstrap.min.css">

	<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">

	<link rel="stylesheet" href="assets/css/owl.carousel.min.css">

	<link rel="stylesheet" href="assets/css/magnific-popup.min.css">

	<link rel="stylesheet" href="assets/css/animate.min.css">

	<link rel="stylesheet" href="assets/css/boxicons.min.css">

	<link rel="stylesheet" href="assets/css/flaticon.css">

	<link rel="stylesheet" href="assets/css/meanmenu.min.css">

	<link rel="stylesheet" href="assets/css/nice-select.min.css">

	<link rel="stylesheet" href="assets/css/odometer.min.css">

	<link rel="stylesheet" href="assets/css/style.css">

	<link rel="stylesheet" href="assets/css/responsive.css">

	<link rel="icon" type="image/png" href="assets/img/favicon.png">


	<?php include 'include_File/head.php';?>





	<title>SGSSPL</title>

</head>

<body>

	<?php include 'include_File/header.php';?>





	<div class="page-title-area bg-1">
		<div class="container">
			<div class="page-title-content">
				<h2>About</h2>
				<ul>
					<li>
						<a href="index.html">
							Home
						</a>
					</li>
					<li class="active">About</li>
				</ul>
			</div>
		</div>
	</div>


	<section class="cybersecurity-area ptb-100">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-6">
					<div class="cybersecurity-content">
						<h2>24/7 Security Operation Center</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
							labore et dolore magna aliqua. Quis ipsum suspendisse.</p>
						<div class="row">
							<div class="col-lg-6 col-sm-6">
								<ul class="cybersecurity-item">
									<li style="border-radius: 20px;">
										<img src="images/01-ico-guard_result.webp" style="width:40px; height:40px">
										<span style="padding-left: 14px;">Security Guard</span>
									</li>
									<li style="border-radius: 20px;">
										<img src="images/02-ico-supervisor_result.webp" style="width:40px; height:40px">
										<span style="padding-left: 14px;">Security Supervisor</span>
									</li>
									<li style="border-radius: 20px;">
										<img src="images/03-ico-gunman_result.webp" style="width:40px; height:40px">
										<span style="padding-left: 14px;">Gun Man</span>
									</li>
									<li style="border-radius: 20px;">
										<img src="images/04-ico-aso_result.webp" style="width:40px; height:40px">
										<span style="padding-left: 14px;">ASO</span>
									</li>
									<li style="border-radius: 20px;">
										<img src="images/05-ico-bouncers_result.webp" style="width:40px; height:40px">
										<span style="padding-left: 14px;">Bouncers</span>
									</li>
								</ul>
							</div>
							<div class="col-lg-6 col-sm-6">
								<ul>
									<li style="border-radius: 20px;">
										<img src="images/ico-armed-pso90px_result.webp" style="width:40px; height:40px">
										<span style="padding-left: 14px;">Armed PSO</span>
									</li>
									<li style="border-radius: 20px;">
										<img src="images/07-ico-fire_result.webp" style="width:40px; height:40px">
										<span style="padding-left: 14px;">Fire Safety Expert</span>
									</li>
									<li style="border-radius: 20px;">
										<img src="images/08-ico-surv_result.webp" style="width:40px; height:40px">
										<span style="padding-left: 14px;">Surveillance Room</span>
									</li>
									<li style="border-radius: 20px;">
										<img src="images/pngwing.com (3)_result.webp" style="width:40px; height:40px">
										<span style="padding-left: 14px;">Security</span>
									</li>
									<li style="border-radius: 20px;">
										<img src="images/pngwing.com (3)_result.webp" style="width:40px; height:40px">
										<span style="padding-left: 14px;">Security</span>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-6 pr-0">
					<div class="cybersecurity-img"></div>
				</div>
			</div>
		</div>
	</section>







	<section class="approach-area ptb-100">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-6">
					<div class="approach-img">
						<img src="images/about1_result.webp" alt="Image">
					</div>
				</div>
				<div class="col-lg-6">
					<div class="approach-content">
						<h2>Our Approach To Security</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
							labore et dolore magna aliqua. Quis ipsumv</p>
						<ul>
							<li>
								
								<h3>Secure by Design</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
									incididunt ut suspendisse ultrices</p>
							</li>
							<li>

								<h3>Compliant by Design</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
									incididunt ut suspendisse ultrices</p>
							</li>
							<li>
							
								<h3>Continuous Monitoring</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
									incididunt ut suspendisse ultrices</p>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>


	


	<?php include 'include_File/footer.php';?>





	<div class="go-top">
		<i class='bx bx-chevrons-up'></i>
		<i class='bx bx-chevrons-up'></i>
	</div>


	<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
	<script src="assets/js/jquery.min.js"></script>

	<script src="assets/js/bootstrap.bundle.min.js"></script>

	<script src="assets/js/meanmenu.min.js"></script>

	<script src="assets/js/owl.carousel.min.js"></script>

	<script src="assets/js/carousel-thumbs.min.js"></script>

	<script src="assets/js/wow.min.js"></script>

	<script src="assets/js/nice-select.min.js"></script>

	<script src="assets/js/magnific-popup.min.js"></script>

	<script src="assets/js/ofi.min.js"></script>

	<script src="assets/js/jarallax.min.js"></script>

	<script src="assets/js/appear.min.js"></script>

	<script src="assets/js/odometer.min.js"></script>

	<script src="assets/js/form-validator.min.js"></script>

	<script src="assets/js/contact-form-script.js"></script>

	<script src="assets/js/ajaxchimp.min.js"></script>

	<script src="assets/js/custom.js"></script>
</body>

</html>